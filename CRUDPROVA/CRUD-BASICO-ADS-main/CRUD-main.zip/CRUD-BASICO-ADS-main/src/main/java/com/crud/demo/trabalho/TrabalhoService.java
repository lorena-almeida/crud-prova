package com.crud.demo.trabalho;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TrabalhoService {

    @Autowired
     private TrabalhoRepository bookRepository;


    public List<TrabalhoModel> findAll(){
        return  bookRepository.findAll();
    }

    public TrabalhoModel criarLivro(TrabalhoModel bookModel){
        return bookRepository.save(bookModel);
    }

    public void deletarLivro(Long id){
        bookRepository.deleteById(id);
    }

    public TrabalhoModel update(Long id, TrabalhoModel bookMode){
       TrabalhoModel newbook =  bookRepository.findById(id).get();
       newbook.setCategoria(bookMode.getCategoria());
       newbook.setNome(bookMode.getNome());
       return bookRepository.save(newbook);

    }

    public void deletarTrabalho(Long id) {
    }
}
